import React, { Component } from 'react'
import Layout from '../layout/Layout'
import axios from 'axios'

class Mainlogic extends Component {
    constructor(props) {
        super(props);
        this.state ={
            data:[],
        }
    }
    csvtoJSON = (csv) => {
        const lines = csv.split('\n')
        let result = []
        let headers = lines[0].split('|')

        for (let i = 2; i < lines.length; i++) {        
            if (!lines[i])
                continue
            const obj = {}
            const currentline = lines[i].split('|')

            for (let j = 0; j < headers.length; j++) {
                let trimheader=headers[j].trim()
                obj[trimheader] = currentline[j];

            }

            result.push(obj)
        }
    
        console.log(result);

        return result
    }
    componentDidMount = () => {
        
        axios.get('https://raw.githubusercontent.com/openbangalore/bangalore/master/bangalore/Education/Bangalore_schools.csv').then(response =>{
            //console.log(response)
            let jsonData = this.csvtoJSON(response.data);
            let categories = {};
            jsonData.forEach( item => {
                categories[item.medium_of_inst] = "";
            })
            console.log(categories);
            this.setState({data:jsonData})
            /*
            this.setState({coustmernamelist : response.data.customer_name,
                customeridlist:response.data.coustomer_id
            });
            */
        });

    }

  render() {
    return (
      <div>
          <Layout data={this.state.data} ></Layout>
      </div>
    )
  }
}

export default Mainlogic
