import React from 'react';
import logo from './logo.svg';
import './App.css';
import Mainlogic from './component/Mainlogic'
function App() {
  return (
    <div >
      <Mainlogic></Mainlogic>
    </div>
  );
}

export default App;
